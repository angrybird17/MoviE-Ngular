import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-seat-layout',
  templateUrl: './seat-layout.component.html',
  styleUrls: ['./seat-layout.component.css']
})
export class SeatLayoutComponent implements OnInit {

  constructor(service: DataService) {
  }

  ngOnInit(): void {
  }

  onCLick() {
    console.log('started');
    var span:any = document.getElementsByClassName('sNum');
    span.style.background = 'rgb(104, 177, 104) !important';
    span.style.color = 'white';
    console.log('clicked');
  }
  isActive: boolean = true;
  seats = [1, 2, 3, 4, 5, 6, 7, 8, 9];
}
