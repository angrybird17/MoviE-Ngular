import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {

  count: any[];

  form = new FormGroup({
    count: new FormControl('', Validators.required)
  });

  get mCount() {
    return this.form.get('count');
  }
  constructor(private service: DataService) { }

  ngOnInit(): void {
  }
  // count = [1, 2];

  login () {
    this.form.setErrors({
      invalidLogin: true
    });
  }

  onSubmit() {
    this.service.createData(JSON.stringify(this.form.value))
    .subscribe( response => {
      // this.form.reset();
    console.log(response);
  });
  }

  checkBoxLimit() {
    console.log('start');
    var checkBoxGroup = document.forms['form']['count'];			
    var limit = 2;
    for (var i = 0; i < checkBoxGroup.length; i++) {
      checkBoxGroup[i].onclick = function() {
        var checkedcount = 0;
        for (var i = 0; i < checkBoxGroup.length; i++) {
          checkedcount += (checkBoxGroup[i].checked) ? 1 : 0;
        }
        if (checkedcount > limit) {
          console.log("You can select maximum of " + limit + " checkboxes.");
          alert("You can select maximum of " + limit + " checkboxes.");						
          this.checked = false;
        }
      }
    }
    console.log('end');
  }
}
